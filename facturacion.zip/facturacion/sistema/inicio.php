
<?php 
	session_start();

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Bienvenidos</title>
</head>
<body>
    <br>
    <br>
   
	<?php include "includes/header.php"; ?>
	
    
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
		 <section id="bienve">
             <br>
      <div class="contenedor">
          <h1>Estamos para ti</h1>
          
        <p>amamos a tu mascota .</p>
      </div>
    </section>


	
	<?php include "includes/footer.php"; ?>
</body>
</html>